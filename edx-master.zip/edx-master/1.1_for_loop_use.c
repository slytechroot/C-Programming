#include <stdio.h>

int main(void)
{
	int i=0;
	for(i=0; i<3; i++)
	{
		printf("C is fun!\n");
	}
	return 0;
}

/*You would like to display the same line of text several times, but you do not wish to have to type it multiple times in your program.

Please print the following text to the screen:

C is fun!
C is fun!
C is fun!
*/
